#include "play_shared.h"
#include "Player.h"
#include "Toobar.h"
#include "GameMap.h"
#include "MainLayer.h"

Player* g_player = nullptr;

MainLayer* mainlayer = nullptr;

GameMap* gamemap = nullptr;

Toolbar* toolbar = nullptr;