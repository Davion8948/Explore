#include "Toobar.h"
#include "cocostudio/CocoStudio.h"
#include "UserData.h"
using namespace cocostudio;

Toolbar::Toolbar()
{

}

Toolbar::~Toolbar()
{

}

bool Toolbar::init()
{
	Return_False_If(!Layer::init());

	ui::Widget* tool_widget = GUIReader::getInstance()->widgetFromJsonFile("eui/toolbar.json");
	addChild(tool_widget);
	setContentSize(tool_widget->getContentSize());

	m_ui[prop_heart].pUI = tool_widget->getChildByName("heart");
	m_ui[prop_heart].pText = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("heart_num"));
	m_ui[prop_shield].pUI = tool_widget->getChildByName("shield");
	m_ui[prop_shield].pText = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("shield_num"));
	m_ui[prop_key].pUI = tool_widget->getChildByName("key");
	m_ui[prop_key].pText = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("key_num"));
	m_ui[prop_arrow].pUI = tool_widget->getChildByName("arrow");
	m_ui[prop_arrow].pText = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("arrow_num"));
	m_ui[prop_hoe].pUI = tool_widget->getChildByName("hoe");
	m_ui[prop_hoe].pText = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("hoe_num"));
	m_ui[prop_bomb].pUI = tool_widget->getChildByName("bomb");
	m_ui[prop_bomb].pText = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("bomb_num"));
	m_ui[prop_map].pUI = tool_widget->getChildByName("map");
	m_ui[prop_map].pText = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("map_num"));

	m_pCloverBtn = dynamic_cast<ui::Button*>(tool_widget->getChildByName("clover"));
	m_pCoinNum = dynamic_cast<ui::TextAtlas*>(tool_widget->getChildByName("coin_num"));

	refreshDisplay();
	return true;
}

void Toolbar::refreshDisplay()
{
	setCoin(UserData::inst().getValue(UserData::udi_coin));
	for (int i=prop_heart; i<prop_count; ++i)
	{
		setProperty((PropType)i, UserData::inst().getValue((UserData::UserDataIndex)i));
	}
	setClover(UserData::inst().getValue(UserData::udi_clover));

// 	for (int i=prop_heart; i<prop_count; ++i)
// 	{
// 		int num = stoi(m_ui[i].pText->getString());
// 		m_ui[i].pUI->setVisible( num!=0 );
// 	}
}

void Toolbar::setClover( int val )
{
	m_pCloverBtn->setVisible( val!=0 );
}

void Toolbar::setCoin( int coin )
{
// 	int cur = stoi(m_pCoinNum->getString());
// 	int diff = (coin-cur)/30;
// 	if (diff==0)
// 		diff = coin>cur ? 1 : -1;
// 
// 	std::function<void(int)> auto_inc = [=](int diff)
// 	{
// 		int cur = stoi(m_pCoinNum->getString());
// 		Return_If(cur == coin);
// 		m_pCoinNum->setString( to_string(abs(coin-cur)<abs(diff) ? coin : cur+diff) ); 
// 	};
// 	runAction( Repeat::create( Sequence::create(CallFunc::create(std::bind(auto_inc,diff)), DelayTime::create(1/30.0f), 0), coin-cur) );
	
	m_pCoinNum->setString( to_string(coin) );
}

void Toolbar::setProperty( PropType prop_tag, int val )
{
	CCAssert(val >= 0, "");
	m_ui[prop_tag].pText->setString( to_string(val) );
	m_ui[prop_tag].pUI->setVisible( val>0 );
}
