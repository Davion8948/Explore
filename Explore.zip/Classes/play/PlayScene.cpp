#include "PlayScene.h"
#include "MainLayer.h"

PlayScene::PlayScene(void)
{
}


PlayScene::~PlayScene(void)
{
}

bool PlayScene::init()
{
	Return_False_If(!Scene::init());

	addChild(MainLayer::create());

	return true;
}
